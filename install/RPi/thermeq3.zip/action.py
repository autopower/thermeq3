try:
    import RPi.GPIO as GPIO
except ImportError:
    print "Error importing RPi.GPIO library!"
    pass

# if relay type is normally closed, set to True, normally open set to False
relay_type = False
gpio_setup = {"relay": 4, "app": 17, "error": 27, "boiler": 22}


def start():
    GPIO.setwarnings(False)
    GPIO.setmode(GPIO.BCM)
    GPIO.setup(4, GPIO.OUT)
    GPIO.setup(17, GPIO.OUT)
    GPIO.setup(27, GPIO.OUT)
    GPIO.setup(22, GPIO.OUT)


def do(action):
    global relay_type
    if relay_type:
        action = not action
    if action:
        gpio_action = GPIO.HIGH
    else:
        gpio_action = GPIO.LOW
    try:
        GPIO.output(4, gpio_action)
    finally:
        pass


def led(**options):
    if options.get("app"):
        GPIO.output(17, GPIO.HIGH)
    else:
        GPIO.output(17, GPIO.LOW)
    if options.get("error"):
        GPIO.output(27, GPIO.HIGH)
    else:
        GPIO.output(27, GPIO.LOW)
    if options.get("boiler"):
        GPIO.output(22, GPIO.HIGH)
    else:
        GPIO.output(22, GPIO.LOW)