try:
    import RPi.GPIO as GPIO
except ImportError:
    print "Error importing RPi.GPIO library!"
    pass

# if relay type is normally closed, set to True, normally open set to False
relay_type = False


def start():
    GPIO.setwarnings(False)
    GPIO.setmode(GPIO.BCM)
    GPIO.setup(4, GPIO.OUT)


def do(action):
    global relay_type
    if relay_type:
        action = not action
    if action:
        gpio_action = GPIO.HIGH
    else:
        gpio_action = GPIO.LOW
    try:
        GPIO.output(4, gpio_action)
    finally:
        pass
