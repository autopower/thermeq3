import platform
import os
import datetime
import urllib2
import config
import action


run_target = ""


def guess_platform():
    """
    :return: Boolean
    """
    global run_target
    gos = str(platform.platform()).upper()
    target = "rpi"
    if "WINDOWS" in gos:
        target = "win"
    elif "LINUX" in gos:
        gm = str(platform.machine()).upper()
        if "MIPS" in gm:
            target = "yun"
        elif "ARM" in gm:
            target = "rpi"
            action.start()
    run_target = target


def is_yun():
    """
    Return True if platform is yun
    :return: Boolean
    """
    global run_target
    if run_target == "yun":
        return True
    else:
        return False


def is_rpi():
    """
    Return True if platform is rpi
    :return: Boolean
    """
    global run_target
    if run_target == "rpi":
        return True
    else:
        return False


def is_win():
    """
    Return True if platform is win
    :return: Boolean
    """
    global run_target
    if run_target == "win":
        return True
    else:
        return False


def get_uptime():
    if os.name != "nt":
        with open("/proc/uptime", "r") as f:
            uptime_seconds = float(f.readline().split()[0])
            return_str = str(datetime.timedelta(seconds=uptime_seconds)).split(".")[0]
    else:
        uptime = os.popen('systeminfo', 'r')
        # obfuscate warning
        data = uptime.readlines()
        data += ""
        uptime.close()
        return_str = str(0)
    return return_str


def is_empty(var):
    if var == "" or var is None or var == "None":
        return True
    else:
        return False


def io_error(err):
    """
    :param err: Exception handler
    :return: string
    """
    return "I/O error({0}): {1}".format(err.errno, err.strerror)


def call_home(selector):
    if selector == "apprun":
        url = "https://www.google-analytics.com/collect?v=1&t=event&tid=UA-106611241-1&cid=1&ec=App&ea=Run"
    elif selector == "applive":
        url = "https://www.google-analytics.com/collect?v=1&t=event&tid=UA-106611241-1&cid=1&ec=App&ea=Live"
    else:
        url = "https://www.google-analytics.com/collect?v=1&t=event&tid=UA-106611241-1&cid=1&ec=App&ea=Other"
    try:
        urllib2.urlopen(url).read()
    except Exception:
        pass


def getRootPath():
    global run_target
    if is_yun():
        _tmp_path = "/root/"
    elif is_rpi():
        _tmp_path = "/home/pi/thermeq3/"
    else:
        _tmp_path = "t:/root/"
    return _tmp_path


def getFolderPath():
    _tmp_path = ""
    if is_win():
        if os.path.exists("t:/mnt/sda1"):
            _tmp_path = "t:/mnt/sda1/"
        elif os.path.exists("t:/mnt/sdb1"):
            _tmp_path = "t:/mnt/sdb1/"
    elif is_yun():
        if os.path.ismount("/mnt/sda1") or os.path.isdir("/mnt/sda1"):
            _tmp_path = "/mnt/sda1/"
        elif os.path.ismount("/mnt/sdb1") or os.path.isdir("/mnt/sdb1"):
            _tmp_path = "/mnt/sdb1/"
    elif is_rpi():
        if os.path.ismount("/home/pi/thermeq3") or os.path.isdir("/home/pi/thermeq3"):
            _tmp_path = "/home/pi/thermeq3/"
    return _tmp_path != "", _tmp_path


def getWWWPath():
    _tmp_path = ""
    if is_win():
        _tmp_path = "t:/mnt/sda1/www/"
    elif is_yun():
        if os.path.ismount("/mnt/sda1") or os.path.isdir("/mnt/sda1"):
            _tmp_path = "/mnt/sda1/www/"
        elif os.path.ismount("/mnt/sdb1") or os.path.isdir("/mnt/sdb1"):
            _tmp_path = "/mnt/sdb1/www/"
    elif is_rpi():
        _tmp_path = "/var/www/html/"
    return _tmp_path


def convertConfig():
    _tmp_error = ""
    _tmp_path = getRootPath()
    _old = _tmp_path + "config.py"
    _new = _tmp_path + "thermeq3.json"
    result = config.load_old(_old, _new)
    if result == 1:
        _tmp_error = "Info: can't find old config file.\n"
    elif result == 2:
        _tmp_error = "Info: error processing old config file.\n"
    elif result == 3:
        _tmp_error = "Info: you can't see something like this.\n"
    elif result == 4:
        _tmp_error = "Info: error processing new config file.\n"
    elif result == 0:
        if is_win():
            cmd = "ren " + _old + " config.old"
            os.system(cmd.replace("/", "\\"))
        else:
            os.system("mv " + _old + " " + _tmp_path + "config.old")
    return _tmp_error, _old, _new
