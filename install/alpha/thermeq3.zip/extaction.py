import requests
import requests.auth
import logmsg

# feel free to add more actuators or components
actuator_setup = {"relay": ["digest", "username", "password", "post", "url_1", "action_off", "action_on"],
                  "app": ["digest", "username", "password", "post", "url_2", "action_off", "action_on"],
                  "error": ["digest", "username", "password", "post", "url_3", "action_off", "action_on"],
                  "boiler": ["digest", "username", "password", "post", "url_4", "action_off", "action_on"]}
ext_action_setup = False


def _return_auth(_method, _uname, _pwd):
    if _method == "digest":
        _auth = requests.auth.HTTPDigestAuth(_uname, _pwd)
    elif _method == "basic":
        _auth = requests.auth.HTTPBasicAuth(_uname, _pwd)
    elif _method == "none":
        _auth = ""
    else:
        _auth = "error"
    return _auth


def start():
    """
    Do some setup if needed
    :return:
    """
    global ext_action_setup, actuator_setup
    for k, v in actuator_setup.iteritems():
        if len(v) > 4:
            _auth = _return_auth(v[0], v[1], v[2])
            if not _auth == "error":
                _response = requests.get(v[4], _auth)
                logmsg.update("Response code for actuator: " + str(k) + "=" + str(_response.status_code), 'D')
                if _response.status_code == 200:
                    pass
            else:
                logmsg.update("Wrong auth method for actuator: " + str(k), 'E')
    ext_action_setup = True


def url_action(_locator, _action):
    # /<domain>/<id>[/<method>?<param>=<value>]
    if not ext_action_setup:
        start()
    _a = actuator_setup[_locator]
    if _a[6][0] != "/":
        _delimiter = "/"
    else:
        _delimiter = ""
    if _action:
        _url = _a[4] + _delimiter + _a[6]
    else:
        _url = _a[4] + _delimiter + _a[5]

    _auth = _return_auth(_a[0], _a[1], _a[2])
    if not _auth == "error":
        _response = requests.post(url=_url, auth=_auth)
    else:
        _response = None
    return _response.content
