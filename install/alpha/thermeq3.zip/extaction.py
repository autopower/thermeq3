import requests
# if relay type is normally closed, set to True, normally open set to False
relay_type = False
actuator_setup = {"relay": ["url_1", "name_1"],
                  "app": ["url_2", "name_2"],
                  "error": ["url_3", "name_3"],
                  "boiler": ["url_4", "name_4"]}
ext_action_setup = False
# please edit strings below to suit your device needs, this one is for esphome switch
ext_action = ["turn_off", "turn_on"]


def start():
    """
    Do some setup if needed
    :return:
    """
    global ext_action_setup, actuator_setup
    for k, v in actuator_setup.iteritems():
        # do some checking, e.g. if connection is possible or not
        pass
    ext_action_setup = True


def url_action(_locator, _action):
    # /<domain>/<id>[/<method>?<param>=<value>]
    _url = actuator_setup[_locator][0]
    _name = actuator_setup[_locator][1]
    # POST request to device
    _payload = '/relay/' + _name + '/' + _action
    _headers = {'Authorization': ''}
    _response = requests.post(url=_locator + _payload)
    return _response.content


def do(action):
    """
    Turn on relay according to relay_type
    :param action:
    :return:
    """
    global relay_type, actuator_setup, ext_action
    if not ext_action_setup:
        start()
    if relay_type:
        action = not action
    if action:
        _ext_action = ext_action[1]
    else:
        _ext_action = ext_action[0]
    try:
        url_action("relay", _ext_action)
    finally:
        pass


def led(**options):
    """
    Turn on or off LED on pin described in actuator_setup
    :param options:
    :return:
    """
    global actuator_setup, ext_action
    if not ext_action_setup:
        start()
    for k, v in actuator_setup.iteritems():
        if k in options:
            if options.get(k):
                url_action(k, ext_action[1])
            else:
                url_action(k, ext_action[0])
