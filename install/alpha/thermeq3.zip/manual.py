import time
import datetime
import support

manual_hours = []
actual_mode = -1
init = False
reason = ""


def is_time():
    """
    :return:
    """
    global manual_hours
    this_now = datetime.datetime.now().time()
    ret_value = -1
    for k in manual_hours:
        nf = datetime.datetime.strptime(k[0], "%H:%M").time()
        nt = datetime.datetime.strptime(k[1], "%H:%M").time()
        if support.time_in_range(nf, nt, this_now):
            ret_value = manual_hours.index(k)
    return ret_value


def default_hours(_diff=3, _dur=30):
    global manual_hours
    if _diff > 23:
        _diff = 12
    if _dur > 59:
        _dur = 30
    for k in range(0, 23, _diff):
        _h = str(k).zfill(2)
        _tmp_1 = _h + ":" + "00"
        _tmp_2 = _h + ":" + str(_dur).zfill(2)
        manual_hours.append([_tmp_1, _tmp_2])


def check_manual_table():
    """
    :return:
    """
    global manual_hours, init

    if len(manual_hours) > 1:
        for i in range(len(manual_hours) - 1):
            if time.strptime(manual_hours[i + 1][0], "%H:%M") <= time.strptime(manual_hours[i][0], "%H:%M"):
                default_hours()
    elif not manual_hours:
        default_hours(2, 30)
    init = True


def manual_mode_heat():
    """
    :return:
    """
    global manual_hours, actual_mode, init, reason
    # day = [0-from_str, 1-to_str]
    if not init:
        check_manual_table()
    _md = is_time()
    if _md != -1:
        if _md != actual_mode:
            actual_mode = _md
            _kv = manual_hours[_md]
            reason = "ID: " + str(_md) + "=" + str(_kv)
        return True
    else:
        return False

