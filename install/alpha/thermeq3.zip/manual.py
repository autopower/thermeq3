import logmsg
import time
import datetime
import support

manual_hours = []
actual_mode = -1


def is_time():
    """
    :return:
    """
    global manual_hours
    this_now = datetime.datetime.now().time()
    ret_value = -1
    for k in manual_hours:
        nf = datetime.datetime.strptime(k[0], "%H:%M").time()
        nt = datetime.datetime.strptime(k[1], "%H:%M").time()
        if support.time_in_range(nf, nt, this_now):
            ret_value = manual_hours.index(k)
    # logmsg.update("IsTime=" + str(ret_value))
    return ret_value


def check_manual_table():
    """
    :return:
    """
    global manual_hours
    if len(manual_hours) > 1:
        for i in range(len(manual_hours) - 1):
            if time.strptime(manual_hours[i + 1][0], "%H:%M") <= time.strptime(manual_hours[i][0], "%H:%M"):
                logmsg.update("Manual mode table is corrupted! Using default table, heating every three hours!", 'E')
                manual_hours = [["03:00", "03:30"],
                                ["06:00", "06:30"],
                                ["09:00", "09:30"],
                                ["12:00", "12:30"],
                                ["15:00", "15:30"],
                                ["18:00", "18:30"],
                                ["21:00", "21:30"],
                                ["00:00", "00:30"]]


def manual_mode():
    """
    :return:
    """
    global manual_hours, actual_mode
    # day = [0-from_str, 1-to_str]
    _md = is_time()
    if _md != -1:
        if _md != actual_mode:
            kv = manual_hours[_md]
            actual_mode = _md
            logmsg.update("Switching to manual heating [" + str(_md) + " = " + str(kv) + "].", 'I')
            return True
    else:
        logmsg.update("Manual heating switched off.", 'I')
        return False
