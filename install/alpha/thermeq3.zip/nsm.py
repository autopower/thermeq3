#!/usr/bin/env python
import thermeq3


if __name__ == '__main__':
    thermeq3.start()
    thermeq3.loop()

