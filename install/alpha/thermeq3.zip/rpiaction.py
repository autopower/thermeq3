try:
    # noinspection PyUnresolvedReferences
    import RPi.GPIO as GPIO
except ImportError:
    print "Error importing RPi.GPIO library!"
    raise

# if relay type is normally closed, set to True, normally open set to False
relay_type = False
gpio_setup = {"relay": 4, "app": 17, "error": 27, "boiler": 22}
rpi_action_setup = False


def start():
    global rpi_action_setup, gpio_setup
    GPIO.setwarnings(False)
    GPIO.setmode(GPIO.BCM)
    for k, v in gpio_setup.iteritems():
        GPIO.setup(v, GPIO.OUT)
    rpi_action_setup = True


def check_init():
    global rpi_action_setup
    if not rpi_action_setup:
        start()


def do(action):
    """
    Turn on relay according to relay_type
    :param action:
    :return:
    """
    global relay_type, gpio_setup
    check_init()
    if relay_type:
        action = not action
    if action:
        gpio_action = GPIO.HIGH
    else:
        gpio_action = GPIO.LOW
    try:
        GPIO.output(gpio_setup.get("relay"), gpio_action)
    finally:
        pass


def led(**options):
    """
    Turn on or off LED on pin described in gpio_setup
    :param options:
    :return:
    """
    global gpio_setup
    check_init()
    for k, v in gpio_setup.iteritems():
        if k in options:
            if options.get(k):
                GPIO.output(v, GPIO.HIGH)
            else:
                GPIO.output(v, GPIO.LOW)
