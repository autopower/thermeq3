import platform
import os
import datetime


run_target = ""


def guess_platform():
    """
    :return: Boolean
    """
    global run_target
    gos = str(platform.platform()).upper()
    target = "rpi"
    if "WINDOWS" in gos:
        target = "win"
    elif "LINUX" in gos:
        gm = str(platform.machine()).upper()
        if "MIPS" in gm:
            target = "yun"
        elif "ARM" in gm:
            target = "rpi"
    run_target = target


def is_yun():
    """
    Return True if platform is yun
    :return: Boolean
    """
    global run_target
    if run_target == "yun":
        return True
    else:
        return False


def is_rpi():
    """
    Return True if platform is rpi
    :return: Boolean
    """
    global run_target
    if run_target == "rpi":
        return True
    else:
        return False


def is_win():
    """
    Return True if platform is win
    :return: Boolean
    """
    global run_target
    if run_target == "win":
        return True
    else:
        return False


def get_uptime():
    if os.name != "nt":
        with open("/proc/uptime", "r") as f:
            uptime_seconds = float(f.readline().split()[0])
            return_str = str(datetime.timedelta(seconds=uptime_seconds)).split(".")[0]
    else:
        uptime = os.popen('systeminfo', 'r')
        # obfuscate warning
        data = uptime.readlines()
        data += ""
        uptime.close()
        return_str = str(0)
    return return_str
