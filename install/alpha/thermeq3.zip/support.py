import platform
import os
import json
import datetime
import urllib2
import logmsg


def _in_docker():
    """
    check if running in docker
    :return: Boolean
    """
    _path = '/proc/self/cgroup'
    return (
            os.path.exists('/.dockerenv') or
            os.path.isfile(_path) and any('docker' in line for line in open(_path))
    )


class thermeq3_platform(object):
    def __init__(self):
        self.err_str = ""
        self.platform_id = ["yun", "rpi", "docker", "win"]
        self.path_candidates = {self.platform_id[0]: ["/mnt/sda1", "/mnt/sdb1"],
                                self.platform_id[1]: ["/home/pi/thermeq3"],
                                self.platform_id[2]: ["/mnt/data"],
                                self.platform_id[3]: ["t:/mnt/sda1", "t:/mnt/sdb1"]}
        self.paths = {self.platform_id[0]: {"home": "/root/", "www": "_WWW_", "log": "_LOG_", "csv": "_CSV_"},
                      self.platform_id[1]: {"home": "/home/pi/thermeq3/", "www": "/var/www/html/", "log": "_LOG_",
                                            "csv": "_CSV_"},
                      self.platform_id[2]: {"home": "/thermeq3/", "www": "_WWW_", "log": "_LOG_", "csv": "_CSV_"},
                      self.platform_id[3]: {"home": "t:/root/", "www": "_WWW_", "log": "_LOG_", "csv": "_CSV_"}}
        self.target = None
        self.homePath = ""
        self.csvPath = ""
        self.rootPath = ""
        self.wwwPath = ""
        self.guess()
        if not self._getDataPath():
            print "Error: can't find mounted storage device!\n" + \
                  "Please mount SD card or USB key and run program again.\n"
            quit()

    @staticmethod
    def _check_folder(_path):
        return os.path.ismount(_path) or os.path.isdir(_path)

    def is_it(self, _platform):
        return self.target == _platform

    def _getDataPath(self):
        _tmp_path = ""

        for i in self.platform_id:
            if self.is_it(i):
                for k in self.path_candidates[i]:
                    if i == "win":
                        if os.path.exists(k):
                            _tmp_path = k
                            break
                    else:
                        if self._check_folder(k):
                            _tmp_path = k
                            break
        if _tmp_path != "":
            if _tmp_path[:-1] != "/":
                _tmp_path += "/"
            self.paths[self.target]["log"] = _tmp_path
            self.paths[self.target]["www"] = _tmp_path + "www/"
            self.paths[self.target]["csv"] = _tmp_path + "csv/"
            self.rootPath = self.paths[self.target]["log"]
            self.wwwPath = self.paths[self.target]["www"]
            self.homePath = self.paths[self.target]["home"]
            self.csvPath = self.paths[self.target]["csv"]

            return True
        else:
            return False

    def guess(self):
        """
        Guess platform
        :return: Boolean
        """
        if _in_docker():
            self.target = self.platform_id[2]
        else:
            gos = str(platform.platform()).upper()
            self.target = self.platform_id[1]
            if "WINDOWS" in gos:
                self.target = self.platform_id[3]
            elif "LINUX" in gos:
                gm = str(platform.machine()).upper()
                if "MIPS" in gm:
                    self.target = self.platform_id[0]
                elif "ARM" in gm:
                    self.target = self.platform_id[1]


t3_platform = thermeq3_platform()


def is_it(_platform):
    """
    Check if running on _platform, if so, return True
    :param _platform: ["yun", "rpi", "win", "docker", "standalone"]
    :return: Boolean
    """
    global t3_platform
    return t3_platform.target == _platform


def get_uptime():
    if os.name != "nt":
        with open("/proc/uptime", "r") as f:
            uptime_seconds = float(f.readline().split()[0])
            return_str = str(datetime.timedelta(seconds=uptime_seconds)).split(".")[0]
    else:
        uptime = os.popen('systeminfo', 'r')
        # obfuscate warning
        data = uptime.readlines()
        data += ""
        uptime.close()
        return_str = str(0)
    return return_str


def is_empty(var):
    return var == "" or var is None or var == "None"


def io_error(err):
    """
    :param err: Exception handler
    :return: string
    """
    return "I/O error({0}): {1}".format(err.errno, err.strerror)


def call_home(selector):
    if selector == "apprun":
        url = "https://www.google-analytics.com/collect?v=1&t=event&tid=UA-106611241-1&cid=1&ec=App&ea=Run"
    elif selector == "applive":
        url = "https://www.google-analytics.com/collect?v=1&t=event&tid=UA-106611241-1&cid=1&ec=App&ea=Live"
    else:
        url = "https://www.google-analytics.com/collect?v=1&t=event&tid=UA-106611241-1&cid=1&ec=App&ea=Other"
    try:
        urllib2.urlopen(url).read()
    except Exception:
        logmsg.update("Error during calling home!", 'E')


def convertConfig():
    global t3_platform

    _tmp_error = ""
    _tmp_path = t3_platform.homePath
    _old = _tmp_path + "config.py"
    _new = _tmp_path + "thermeq3.json"
    result = load_old_config(_old, _new)
    if result == 1:
        _tmp_error = "Info: can't find old config file.\n"
    elif result == 2:
        _tmp_error = "Info: error processing old config file.\n"
    elif result == 3:
        _tmp_error = "Info: you can't see something like this.\n"
    elif result == 4:
        _tmp_error = "Info: error processing new config file.\n"
    elif result == 0:
        if is_it("win"):
            cmd = "ren " + _old + " config.old"
            os.system(cmd.replace("/", "\\"))
        else:
            os.system("mv " + _old + " " + _tmp_path + "config.old")
    return _tmp_error, _old, _new


def load_old_config(old_config_file, new_config_file):
    cf_1 = ["self.devname", "self.max_ip", "self.fromaddr", "self.toaddr", "self.mailserver", "self.mailport",
            "self.frompwd", "self.owm_api_key", "self.location", "self.extport"]
    cf_2 = ["self.device_name", "self.max_ip", "self.from_addr", "self.to_addr", "self.mail_server", "self.mail_port",
            "self.from_pwd", "self.owm_api_key", "self.yahoo_location", "self.ext_port"]
    ncf = {}
    result = 0xFF
    if os.path.exists(old_config_file):
        try:
            f = open(old_config_file, "r")
        except IOError:
            result = 1
        else:
            num = 0
            for line in f:
                is_comment = line.find('#')
                if is_comment == 0:
                    pass
                else:
                    if is_comment > 0:
                        line = line[:-is_comment]
                    w = line.split("=")
                    wr = w[0].rstrip()
                    if not w[0] == "\n":
                        if "toaddr" in wr:
                            wv = w[1].lstrip().rstrip()
                        else:
                            wv = w[1].lstrip().rstrip().replace('"', '')
                        if wr in cf_1:
                            num += 1
                            idx = cf_1.index(wr)
                            ncf.update({cf_2[idx].replace("self.", ""): str(wv)})
            if num < len(cf_1):
                # some commands are missing
                result = 2
            else:
                # everything is ok
                result = 3
            f.close()
            try:
                f = open(new_config_file, "w")
            except IOError:
                result = 4
            else:
                json.dump(ncf, f)
                f.close()
                result = 0
    return result


def load_config(config_file):
    f = None
    result = {}
    try:
        f = open(config_file, "r")
    except IOError:
        pass
    else:
        if f is not None:
            result = json.load(f)
    finally:
        if f is not None:
            f.close()
    return result


def save_proxy_file(content):
    global t3_platform

    _proxy_file = t3_platform.wwwPath + 'proxy.eq3'
    try:
        f = open(_proxy_file, "w")
    except IOError:
        logmsg.update("Can't create proxy.eq3 file!", 'E')
    else:
        for line in content:
            f.write(str(line))
        f.close()
        logmsg.update("Proxy file (" + str(_proxy_file) + ") saved.", 'D')


def time_in_range(start, end, x):
    """
    :param start:
    :param end:
    :param x:
    :return:
    """
    today = datetime.date.today()
    start = datetime.datetime.combine(today, start)
    end = datetime.datetime.combine(today, end)
    x = datetime.datetime.combine(today, x)
    if end <= start:
        end += datetime.timedelta(1)  # tomorrow!
    if x <= start:
        x += datetime.timedelta(1)  # tomorrow!
    return start <= x <= end
