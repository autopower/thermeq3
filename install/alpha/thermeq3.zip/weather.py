import logmsg
import traceback
from math import exp
import json
import bridge
import time
import uuid
import urllib
import urllib2
import hmac
import hashlib
from base64 import b64encode


def get_weather(mode, data):
    """
    Get current weather for var.situation variable
    :param mode: string, mode "yahoo", "owm" or "local"
    :param data: dictionary
    :return:
    """
    if mode == "LOCAL":
        result = local_weather()
    elif mode == "OWM":
        result = owm_weather(data["owm_id"], data["owm_api_key"])
    else:
        result = new_yahoo_weather(data["woe_id"], data["yahoo"])
    logmsg.update(
        "Current temperature in " + str(result["city"]) + " is " + str(result["current_temp"]) + ", humidity " +
        str(result["humidity"]) + "%", 'I')
    return result


def owm_weather(owm_id, owm_api_key):
    """
    Returns weather from OWM weather from given OWMID
    :param owm_id: location ID
    :param owm_api_key:
    :return: dictionary, {"current_temp": temp, "city": city, "humidity": humidity}
    """
    city, temp, humidity = "Error city", None, None

    if owm_id is None:
        logmsg.update("Wrong WOEID! Please set WOEID in configuration file.", 'E')
    elif owm_api_key is None:
        logmsg.update("OWM API key not set!", 'E')
    else:
        # and check if yahoo is correct
        url = "http://api.openweathermap.org/data/2.5/weather?id=" + str(owm_id) + "&appid=" + \
              owm_api_key + "&units=metric"
        try:
            result = json.load(urllib2.urlopen(url))
        except Exception, error:
            logmsg.update("OWM communication error: " + str(error), 'E')
            logmsg.update("Traceback: " + str(traceback.format_exc()), 'E')
        else:
            if "main" in result:
                temp = float(result["main"]["temp"])
                city = result["name"]
                humidity = int(result["main"]["humidity"])
            else:
                logmsg.update("Error during parsing result.", 'D')
        logmsg.update(
            "Current temperature in " + str(city) + " is " + str(temp) + ", humidity " + str(humidity) + "%", 'I')

    return {
        "current_temp": temp,
        "city": city,
        "humidity": humidity
    }


def local_weather():
    """
    Get local temp and humidity from bridge, bridge values are update manually by external app or user!!!
    :return:
    """
    return {
        "current_temp": float(bridge.try_read("lt")),
        "city": "local",
        "humidity": float(bridge.try_read("lh"))
    }


def _scale(val, src, dst):
    """ Scale the given value from the scale of src to the scale of dst
    :param val: float, value to scale
    :param src: list, scale interval from
    :param dst: list, scale interval to
    :return: float
    """
    return ((val - src[0]) / (src[1] - src[0])) * (dst[1] - dst[0]) + dst[0]


def interval_scale(temp, t, r, w, test):
    """
    :param temp: int, temperature
    :param t: list, temperature min, max range
    :param r: list, min, max for exp()
    :param w: list, target range, min max
    :param test: boolean, test for range violation
    :return: int, mapped value
    """
    if test:
        if temp < t[0]:
            temp = t[0]
        elif temp > t[1]:
            temp = t[1]

    a = _scale(temp, t, r)
    b = int(_scale(exp(a), (exp(r[0]), exp(r[1])), w))

    return b


# noinspection PyBroadException
def new_yahoo_weather(woe_id, yahoo_data):
    city, temp, humidity = "Error city", None, None

    if woe_id is None:
        logmsg.update("Wrong WOEID! Please set WOEID in config file.", 'E')
    else:
        # basic info
        url = 'https://weather-ydn-yql.media.yahoo.com/forecastrss'
        method = 'GET'
        try:
            data = json.loads(yahoo_data)
        except Exception:
            city, temp, humidity = "Error city", None, None
        else:
            app_id = str(data["app_id"])
            consumer_key = str(data["consumer_key"])
            consumer_secret = str(data["consumer_secret"])
            concat = '&'
            query = {'woeid': str(woe_id), 'format': 'json', 'u': 'c'}
            oauth = {
                'oauth_consumer_key': consumer_key,
                'oauth_nonce': uuid.uuid4().hex,
                'oauth_signature_method': 'HMAC-SHA1',
                'oauth_timestamp': str(int(time.time())),
                'oauth_version': '1.0'
            }

            # Prepare signature string (merge all params and SORT them)
            merged_params = query.copy()
            merged_params.update(oauth)
            sorted_params = [k + '=' + urllib.quote(merged_params[k], safe='') for k in sorted(merged_params.keys())]
            signature_base_str = method + concat + urllib.quote(url, safe='') + concat + urllib.quote(
                concat.join(sorted_params), safe='')

            # Generate signature
            composite_key = urllib.quote(consumer_secret, safe='') + concat
            oauth_signature = b64encode(hmac.new(composite_key, signature_base_str, hashlib.sha1).digest())

            # Prepare Authorization header
            oauth['oauth_signature'] = oauth_signature
            auth_header = 'OAuth ' + ', '.join(['{}="{}"'.format(k, v) for k, v in oauth.iteritems()])

            # Send request
            url = url + '?' + urllib.urlencode(query)
            request = urllib2.Request(url)
            request.add_header('Authorization', auth_header)
            request.add_header('Yahoo-App-Id', app_id)
            try:
                data = urllib2.urlopen(request).read()
            except Exception, error:
                logmsg.update("Yahoo communication error: " + str(error), 'E')
                logmsg.update("Traceback: " + str(traceback.format_exc()), 'E')
            else:
                if data is not None:
                    data = json.loads(data)
                    try:
                        city = data["location"]["city"]
                        temp = float(data["current_observation"]["condition"]["temperature"])
                        humidity = int(data["current_observation"]["atmosphere"]["humidity"])
                    except Exception:
                        pass

    return {
        "current_temp": temp,
        "city": city,
        "humidity": humidity
    }
