try:
    import RPi.GPIO as GPIO
except ImportError:
    print "Error importing RPi.GPIO library!"
    pass

# if relay type is normally closed, set to True, normally open set to False
relay_type = False
gpio_setup = {"relay": 4, "app": 17, "error": 27, "boiler": 22}
action_setup = False


def start():
    global action_setup
    GPIO.setwarnings(False)
    GPIO.setmode(GPIO.BCM)
    GPIO.setup(4, GPIO.OUT)
    GPIO.setup(17, GPIO.OUT)
    GPIO.setup(27, GPIO.OUT)
    GPIO.setup(22, GPIO.OUT)
    action_setup = True


def check_init():
    global action_setup
    if not action_setup:
        start()


def do(action):
    global relay_type
    check_init()
    if relay_type:
        action = not action
    if action:
        gpio_action = GPIO.HIGH
    else:
        gpio_action = GPIO.LOW
    try:
        GPIO.output(4, gpio_action)
    finally:
        pass


def led(**options):
    """
    Turn on or off LED on pin described in gpio_setup
    :param options:
    :return:
    """
    global gpio_setup
    check_init()
    for k, v in gpio_setup:
        if k in options:
            if options.get(k):
                GPIO.output(v, GPIO.HIGH)
            else:
                GPIO.output(v, GPIO.LOW)
