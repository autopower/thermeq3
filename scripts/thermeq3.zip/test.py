import thermeq3

t3 = thermeq3.thermeq3_object()
t3.prepare()
print t3.eq3.json_status()




